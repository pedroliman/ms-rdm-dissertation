`vol.box` <-
function(box)
{
  return(prod(abs(box[2,] - box[1,])))
}

