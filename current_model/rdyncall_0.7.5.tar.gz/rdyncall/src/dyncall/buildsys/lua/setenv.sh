#
PATH=$PWD/lua-5.1.4/src:$PATH
export PATH

